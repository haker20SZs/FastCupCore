<?php

namespace pocketmine\entity;

abstract class RideEntity extends Animal{

}