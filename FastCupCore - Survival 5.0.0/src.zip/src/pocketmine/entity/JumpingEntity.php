<?php

namespace pocketmine\entity;

abstract class JumpingEntity extends BaseEntity{
	
    protected function checkTarget($checkSkip = true){
    	
    }

    public function updateMove(){
        return null;
    }
}