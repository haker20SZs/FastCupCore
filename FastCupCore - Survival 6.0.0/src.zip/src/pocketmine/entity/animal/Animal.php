<?php

namespace pocketmine\entity\animal;

use pocketmine\entity\Ageable;

interface Animal extends Ageable{

}